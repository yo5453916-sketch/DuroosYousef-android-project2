طريقتين لعمل الـ APK:

1) Android Studio (الأسهل): File > Open > اختار فولدر DuroosYousef > استنى Sync > Build > Build APK(s).
   الملف بيطلع في app/build/outputs/apk/.
2) من غير برامج: ارفع الفولدر كله على repo جديد في GitHub (حتى لو Private) > تبويب Actions > Build APK > Run workflow.
   بعد دقايق نزّل duroos-yousef-apk من Artifacts.

لو عدّلت التطبيق: بدّل الملف app/src/main/assets/index.html وابنِ تاني.
أول تشغيل: وافق على الإشعارات (لازم عشان أزرار التحكم والتشغيل في الخلفية).
على أجهزة شاومي/هواوي/سامسونج: من إعدادات البطارية خلّي التطبيق "بدون قيود" عشان النظام ما يقتلوش.
